/*
	TECHNICAL CHALLEGE 
	PART 1
		The objective of the first conversion is to extract only the SPI writes, 
		reads and waits and write them to a text file. 

		INPUT TEXT FILE:-Afe79xxPg1.txt
		OUTPUT TEXT FILE:-Afe79xxPg1_sample_onlySPI.txt
*/
#include <stdio.h>
#include<string.h>

int main(int argc, char* argv[])
{
	char const* const fileName = "Afe79xxPg1.txt";
	FILE* file = fopen(fileName, "r"); 
	FILE* ptr= fopen("Afe79xxPg1_sample_onlySPI.txt","w");
	
	char line[256];
	char word[100], word1[100];
	int len;
	while (fgets(line, sizeof(line), file)) {
		len=0;
		sscanf(line+len, "%s", word );
		if((line[0]!='\n') && (( word[0] =='S' )  && ( word[1] =='P' )  && ( word[2] =='I' )|| (stricmp("WAIT", word ) == 0)))
		{
			fprintf(ptr, "%s ", word );
			len += strlen(word);
			sscanf( line+len, "%s", word1);
			fprintf(ptr,"%s\n", word1 );
		}
		else{
			continue;
		}
	}
	fclose(file);
	fclose(ptr);
	return 0;
}
